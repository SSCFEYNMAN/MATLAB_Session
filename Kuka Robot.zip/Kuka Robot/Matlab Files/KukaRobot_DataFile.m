% Simscape(TM) Multibody(TM) version: 7.3

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(13).translation = [0.0 0.0 0.0];
smiData.RigidTransform(13).angle = 0.0;
smiData.RigidTransform(13).axis = [0.0 0.0 0.0];
smiData.RigidTransform(13).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 363 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[Base-1:-:Arm 1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [112.76762317970881 466.03898900587347 544.62255516462335];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(2).axis = [-0.57735026918962584 -0.57735026918962595 -0.57735026918962562];
smiData.RigidTransform(2).ID = 'F[Base-1:-:Arm 1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [268.02860660234234 748.03898900587342 766.2506829522215];  % mm
smiData.RigidTransform(3).angle = 0.67886542617675194;  % rad
smiData.RigidTransform(3).axis = [-0 -1 0];
smiData.RigidTransform(3).ID = 'B[Arm 1-1:-:Arm 2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-1.2931877790833823e-12 1.8873791418627661e-13 -40.000000000000981];  % mm
smiData.RigidTransform(4).angle = 9.6105630163391647e-16;  % rad
smiData.RigidTransform(4).axis = [0.32669950292294153 -0.94512826367107605 -1.4837408696840129e-16];
smiData.RigidTransform(4).ID = 'F[Arm 1-1:-:Arm 2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [1.1102230246251565e-13 680.00000000000023 -2.9999999999999472];  % mm
smiData.RigidTransform(5).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(5).axis = [1 0 0];
smiData.RigidTransform(5).ID = 'B[Arm 2-1:-:Arm 3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [579.27678483624356 1284.0147415742229 1064.9019247122937];  % mm
smiData.RigidTransform(6).angle = 3.1415926535897913;  % rad
smiData.RigidTransform(6).axis = [0.94294369668473854 3.5621680510225381e-16 0.33295222612639208];
smiData.RigidTransform(6).ID = 'F[Arm 2-1:-:Arm 3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [563.47082977551554 1744.325211937896 885.11610030394115];  % mm
smiData.RigidTransform(7).angle = 2.0922507439739073;  % rad
smiData.RigidTransform(7).axis = [-0.548668813044489 -0.70384950022967807 -0.45117448356349221];
smiData.RigidTransform(7).ID = 'B[Arm 3-1:-:Arm 4-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [-1.6418211515281166e-12 -4.4398207021713989e-13 2.5133558610900171e-12];  % mm
smiData.RigidTransform(8).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(8).axis = [-1 -1.5461248728294002e-32 4.748193286993557e-17];
smiData.RigidTransform(8).ID = 'F[Arm 3-1:-:Arm 4-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 77.000000000000071 -189.99999999999972];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[Arm 4-1:-:Arm 5-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-2.5863755581667647e-12 -1.1368683772161603e-13 -145.00000000000082];  % mm
smiData.RigidTransform(10).angle = 3.1415926535897918;  % rad
smiData.RigidTransform(10).axis = [1 -3.691451661151479e-31 -5.0475292966273113e-16];
smiData.RigidTransform(10).ID = 'F[Arm 4-1:-:Arm 5-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [157.99999999999991 0 -49.000000000000043];  % mm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(11).ID = 'B[Arm 5-1:-:Arm 6-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-2.1781808078160413e-12 2.2463663788186072e-12 6.120790039101824e-13];  % mm
smiData.RigidTransform(12).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(12).axis = [0.57735026918962584 -0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(12).ID = 'F[Arm 5-1:-:Arm 6-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [420.06697266445849 268.75287472759334 420.96042214989552];  % mm
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = 'RootGround[Base-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(7).mass = 0.0;
smiData.Solid(7).CoM = [0.0 0.0 0.0];
smiData.Solid(7).MoI = [0.0 0.0 0.0];
smiData.Solid(7).PoI = [0.0 0.0 0.0];
smiData.Solid(7).color = [0.0 0.0 0.0];
smiData.Solid(7).opacity = 0.0;
smiData.Solid(7).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 26.7899456552842;  % kg
smiData.Solid(1).CoM = [198.17622118942117 638.71244587171532 613.46153471912839];  % mm
smiData.Solid(1).MoI = [674238.79750713473 673245.0705889872 745066.4142737739];  % kg*mm^2
smiData.Solid(1).PoI = [-126362.0072162523 -194039.74129472749 -150879.99682203427];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Arm 1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 70.656654855805201;  % kg
smiData.Solid(2).CoM = [-1.2049510400427894 158.91566716881826 42.6387269980033];  % mm
smiData.Solid(2).MoI = [2152730.9861787651 2204099.9857885689 1737982.0494403522];  % kg*mm^2
smiData.Solid(2).PoI = [60930.21897963556 24318.895470481191 472.27845567477755];  % kg*mm^2
smiData.Solid(2).color = [0.20000000000000001 0.20000000000000001 0.20000000000000001];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'Base*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 2.6168654768978956;  % kg
smiData.Solid(3).CoM = [-0.039363004721700894 8.316854604814969 -119.23371415008826];  % mm
smiData.Solid(3).MoI = [17120.572109044886 16287.435542309235 5178.2699469028385];  % kg*mm^2
smiData.Solid(3).PoI = [1574.8788859705214 -0.84008425861554192 -6.7489047128386286];  % kg*mm^2
smiData.Solid(3).color = [0.90980392156862744 0.44313725490196076 0.031372549019607843];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'Arm 4*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 1.8560018593357066;  % kg
smiData.Solid(4).CoM = [52.440152173835742 0.00132453017759607 -62.537308518529038];  % mm
smiData.Solid(4).MoI = [12259.580626269491 16628.150465258255 7061.8969453022028];  % kg*mm^2
smiData.Solid(4).PoI = [0.22038466145930594 -901.73070173746851 0.07749641804689171];  % kg*mm^2
smiData.Solid(4).color = [0.90980392156862744 0.44313725490196076 0.031372549019607843];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Arm 5*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.39978801939652603;  % kg
smiData.Solid(5).CoM = [-4.77444472401515 -34.789644453602406 -0.0079907880787531364];  % mm
smiData.Solid(5).MoI = [858.79531260749877 1133.9735977772084 649.33274213971299];  % kg*mm^2
smiData.Solid(5).PoI = [-0.14033436104976613 -1.6697555196202085 23.281477534606061];  % kg*mm^2
smiData.Solid(5).color = [0.20000000000000001 0.20000000000000001 0.20000000000000001];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'Arm 6*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 14.291995111832284;  % kg
smiData.Solid(6).CoM = [650.41189331792884 1365.7070230618804 959.70383924481587];  % mm
smiData.Solid(6).MoI = [510712.79461692407 132453.74485654564 518834.58887358138];  % kg*mm^2
smiData.Solid(6).PoI = [87380.96865718656 -16503.413874871621 103281.32818301648];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'Arm 3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 11.860846119324602;  % kg
smiData.Solid(7).CoM = [0.165428920726817 309.41103725901849 50.481290950959647];  % mm
smiData.Solid(7).MoI = [546358.79543076071 55050.9916040526 548724.48106233741];  % kg*mm^2
smiData.Solid(7).PoI = [-23509.43059151429 147.08806240190779 -472.55851530171253];  % kg*mm^2
smiData.Solid(7).color = [0.90980392156862744 0.44313725490196076 0.031372549019607843];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'Arm 2*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(6).Rz.Pos = 0.0;
smiData.RevoluteJoint(6).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 164.99552207154946;  % deg
smiData.RevoluteJoint(1).ID = '[Base-1:-:Arm 1-1]';

smiData.RevoluteJoint(2).Rz.Pos = -13.118068950785284;  % deg
smiData.RevoluteJoint(2).ID = '[Arm 1-1:-:Arm 2-1]';

smiData.RevoluteJoint(3).Rz.Pos = 51.777236433419127;  % deg
smiData.RevoluteJoint(3).ID = '[Arm 2-1:-:Arm 3-1]';

smiData.RevoluteJoint(4).Rz.Pos = 101.46506954232515;  % deg
smiData.RevoluteJoint(4).ID = '[Arm 3-1:-:Arm 4-1]';

smiData.RevoluteJoint(5).Rz.Pos = -171.90547770716432;  % deg
smiData.RevoluteJoint(5).ID = '[Arm 4-1:-:Arm 5-1]';

smiData.RevoluteJoint(6).Rz.Pos = -130.48487120679417;  % deg
smiData.RevoluteJoint(6).ID = '[Arm 5-1:-:Arm 6-1]';

